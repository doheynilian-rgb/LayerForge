import os, sqlite3, secrets
from functools import wraps
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, 'layerforge.db')
UPLOADS = os.path.join(BASE, 'uploads')
os.makedirs(UPLOADS, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', secrets.token_hex(32))
app.config['MAX_CONTENT_LENGTH'] = 8 * 1024 * 1024
ALLOWED = {'png','jpg','jpeg','webp','gif'}
SHOP_EMAIL = 'doheyn.ilian@gmail.com'


def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = db()
    conn.executescript('''
    CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'Overig',
      description TEXT DEFAULT '', price REAL NOT NULL DEFAULT 0, stock INTEGER NOT NULL DEFAULT 0,
      image TEXT DEFAULT '', active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT, customer_name TEXT NOT NULL, email TEXT NOT NULL,
      address TEXT DEFAULT '', note TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'Nieuw',
      total REAL NOT NULL DEFAULT 0, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, product_id INTEGER,
      product_name TEXT NOT NULL, quantity INTEGER NOT NULL, unit_price REAL NOT NULL,
      FOREIGN KEY(order_id) REFERENCES orders(id)
    );
    ''')
    conn.commit(); conn.close()


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get('admin_id'):
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return wrapper


def valid_image(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED


def save_image(file):
    if not file or not file.filename:
        return ''
    if not valid_image(file.filename):
        raise ValueError('Gebruik een PNG, JPG, JPEG, WEBP of GIF afbeelding.')
    ext = secure_filename(file.filename).rsplit('.',1)[1].lower()
    name = secrets.token_hex(12) + '.' + ext
    file.save(os.path.join(UPLOADS, name))
    return name


@app.context_processor
def inject_globals():
    return {'shop_email': SHOP_EMAIL}


@app.route('/')
def home():
    conn = db(); products = conn.execute('SELECT * FROM products WHERE active=1 ORDER BY id DESC').fetchall(); conn.close()
    return render_template('shop.html', products=products)


@app.post('/api/order')
def create_order():
    data = request.get_json(silent=True) or request.form
    name, email = (data.get('name') or '').strip(), (data.get('email') or '').strip()
    address, note = (data.get('address') or '').strip(), (data.get('note') or '').strip()
    items = data.get('items')
    if isinstance(items, str):
        import json
        try: items = json.loads(items)
        except Exception: items = []
    if not name or not email or not isinstance(items, list) or not items:
        return jsonify(ok=False, error='Naam, e-mail en minstens één product zijn nodig.'), 400
    conn=db(); clean=[]; total=0
    try:
        for raw in items:
            pid=int(raw.get('id')); qty=int(raw.get('qty'))
            if qty < 1 or qty > 100: raise ValueError()
            p=conn.execute('SELECT * FROM products WHERE id=? AND active=1', (pid,)).fetchone()
            if not p: raise ValueError('Product bestaat niet meer.')
            if p['stock'] < qty: raise ValueError(f"Niet genoeg voorraad voor {p['name']}.")
            clean.append((p,qty)); total += p['price']*qty
        now=datetime.now().isoformat(timespec='seconds')
        cur=conn.execute('INSERT INTO orders(customer_name,email,address,note,status,total,created_at) VALUES(?,?,?,?,?,?,?)',(name,email,address,note,'Nieuw',total,now))
        oid=cur.lastrowid
        for p,qty in clean:
            conn.execute('INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_price) VALUES(?,?,?,?,?)',(oid,p['id'],p['name'],qty,p['price']))
            conn.execute('UPDATE products SET stock=stock-? WHERE id=?',(qty,p['id']))
        conn.commit()
        return jsonify(ok=True, order_id=oid)
    except ValueError as e:
        conn.rollback(); return jsonify(ok=False,error=str(e) or 'Ongeldige bestelling.'),400
    finally: conn.close()


@app.route('/uploads/<path:filename>')
def uploaded(filename):
    return send_from_directory(UPLOADS, filename)


@app.route('/admin/login', methods=['GET','POST'])
def admin_login():
    if request.method=='POST':
        username=(request.form.get('username') or '').strip(); password=request.form.get('password') or ''
        conn=db(); admin=conn.execute('SELECT * FROM admins WHERE username=?',(username,)).fetchone(); conn.close()
        if admin and check_password_hash(admin['password_hash'], password):
            session['admin_id']=admin['id']; return redirect(url_for('admin_dashboard'))
        flash('Onjuiste login.', 'error')
    return render_template('admin_login.html')


@app.route('/admin/logout')
def admin_logout():
    session.clear(); return redirect(url_for('admin_login'))


@app.route('/admin')
@admin_required
def admin_dashboard():
    conn=db()
    stats={
      'products':conn.execute('SELECT COUNT(*) c FROM products').fetchone()['c'],
      'orders':conn.execute('SELECT COUNT(*) c FROM orders').fetchone()['c'],
      'new_orders':conn.execute("SELECT COUNT(*) c FROM orders WHERE status='Nieuw'").fetchone()['c'],
      'revenue':conn.execute("SELECT COALESCE(SUM(total),0) s FROM orders WHERE status!='Geannuleerd'").fetchone()['s']
    }
    products=conn.execute('SELECT * FROM products ORDER BY id DESC').fetchall()
    orders=conn.execute('SELECT * FROM orders ORDER BY id DESC LIMIT 25').fetchall()
    conn.close(); return render_template('admin.html', stats=stats, products=products, orders=orders)


@app.route('/admin/products/new', methods=['GET','POST'])
@admin_required
def product_new():
    if request.method=='POST':
        try: image=save_image(request.files.get('image'))
        except ValueError as e: flash(str(e),'error'); return render_template('product_form.html', product=None)
        conn=db(); conn.execute('INSERT INTO products(name,category,description,price,stock,image,active,created_at) VALUES(?,?,?,?,?,?,?,?)',(
            request.form.get('name','').strip(), request.form.get('category','Overig').strip(), request.form.get('description','').strip(),
            float(request.form.get('price') or 0), int(request.form.get('stock') or 0), image, 1, datetime.now().isoformat(timespec='seconds'))); conn.commit(); conn.close()
        return redirect(url_for('admin_dashboard'))
    return render_template('product_form.html', product=None)


@app.route('/admin/products/<int:pid>/edit', methods=['GET','POST'])
@admin_required
def product_edit(pid):
    conn=db(); product=conn.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
    if not product: conn.close(); return 'Niet gevonden',404
    if request.method=='POST':
        image=product['image']
        try:
            new=save_image(request.files.get('image'))
            if new: image=new
        except ValueError as e: flash(str(e),'error'); conn.close(); return render_template('product_form.html',product=product)
        conn.execute('UPDATE products SET name=?,category=?,description=?,price=?,stock=?,image=?,active=? WHERE id=?',(
            request.form.get('name','').strip(),request.form.get('category','Overig').strip(),request.form.get('description','').strip(),
            float(request.form.get('price') or 0),int(request.form.get('stock') or 0),image,1 if request.form.get('active') else 0,pid)); conn.commit(); conn.close()
        return redirect(url_for('admin_dashboard'))
    conn.close(); return render_template('product_form.html',product=product)


@app.post('/admin/products/<int:pid>/delete')
@admin_required
def product_delete(pid):
    conn=db(); conn.execute('DELETE FROM products WHERE id=?',(pid,)); conn.commit(); conn.close(); return redirect(url_for('admin_dashboard'))


@app.post('/admin/orders/<int:oid>/status')
@admin_required
def order_status(oid):
    status=request.form.get('status')
    allowed={'Nieuw','In behandeling','Verzonden','Afgerond','Geannuleerd'}
    if status not in allowed: return 'Ongeldige status',400
    conn=db(); conn.execute('UPDATE orders SET status=? WHERE id=?',(status,oid)); conn.commit(); conn.close(); return redirect(url_for('admin_dashboard'))


@app.route('/admin/orders/<int:oid>')
@admin_required
def order_detail(oid):
    conn=db(); order=conn.execute('SELECT * FROM orders WHERE id=?',(oid,)).fetchone(); items=conn.execute('SELECT * FROM order_items WHERE order_id=?',(oid,)).fetchall(); conn.close()
    if not order:return 'Niet gevonden',404
    return render_template('order_detail.html',order=order,items=items)


@app.route('/setup', methods=['GET','POST'])
def setup():
    conn=db(); count=conn.execute('SELECT COUNT(*) c FROM admins').fetchone()['c']
    if count: conn.close(); return redirect(url_for('admin_login'))
    if request.method=='POST':
        username=(request.form.get('username') or '').strip(); password=request.form.get('password') or ''
        if len(username)<3 or len(password)<8: flash('Gebruikersnaam minstens 3 tekens en wachtwoord minstens 8 tekens.','error')
        else:
            conn.execute('INSERT INTO admins(username,password_hash) VALUES(?,?)',(username,generate_password_hash(password))); conn.commit(); conn.close(); return redirect(url_for('admin_login'))
    conn.close(); return render_template('setup.html')


init_db()
if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.environ.get('PORT',5000)),debug=False)
