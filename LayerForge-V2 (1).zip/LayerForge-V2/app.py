import os, sqlite3, uuid
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, 'layerforge.db')
UPLOADS = os.path.join(BASE, 'uploads')
os.makedirs(UPLOADS, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'change-this-in-render')
app.config['MAX_CONTENT_LENGTH'] = 8 * 1024 * 1024
ALLOWED = {'png','jpg','jpeg','webp','gif'}


def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    c = db()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY, name TEXT NOT NULL, description TEXT DEFAULT '', price REAL NOT NULL DEFAULT 0, stock INTEGER NOT NULL DEFAULT 0, image TEXT DEFAULT '', visible INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY, customer_name TEXT NOT NULL, email TEXT NOT NULL, address TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'Nieuw', total REAL NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS order_items (id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL, product_id INTEGER, product_name TEXT NOT NULL, price REAL NOT NULL, quantity INTEGER NOT NULL, FOREIGN KEY(order_id) REFERENCES orders(id));
    ''')
    if not c.execute('SELECT 1 FROM users LIMIT 1').fetchone():
        username = os.environ.get('ADMIN_USERNAME', 'admin')
        password = os.environ.get('ADMIN_PASSWORD', 'change-me')
        c.execute('INSERT INTO users(username,password_hash) VALUES (?,?)', (username, generate_password_hash(password)))
    c.commit(); c.close()


def admin_required(f):
    @wraps(f)
    def w(*a, **kw):
        if not session.get('admin'): return redirect(url_for('login', next=request.path))
        return f(*a, **kw)
    return w


def allowed_file(name): return '.' in name and name.rsplit('.',1)[1].lower() in ALLOWED

@app.context_processor
def globals_():
    return {'cart_count': sum(session.get('cart', {}).values()) if session.get('cart') else 0}

@app.route('/')
def index():
    c=db(); products=c.execute('SELECT * FROM products WHERE visible=1 ORDER BY id DESC').fetchall(); c.close()
    return render_template('index.html', products=products)

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method=='POST':
        username=request.form.get('username','').strip(); password=request.form.get('password','')
        c=db(); u=c.execute('SELECT * FROM users WHERE username=?',(username,)).fetchone(); c.close()
        if u and check_password_hash(u['password_hash'], password):
            session['admin']=True; session['username']=username
            return redirect(request.args.get('next') or url_for('admin'))
        flash('Onjuiste gebruikersnaam of wachtwoord.','error')
    return render_template('login.html')

@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('index'))

@app.route('/admin')
@admin_required
def admin():
    c=db(); products=c.execute('SELECT * FROM products ORDER BY id DESC').fetchall(); orders=c.execute('SELECT * FROM orders ORDER BY id DESC').fetchall()
    stats={'products':c.execute('SELECT COUNT(*) n FROM products').fetchone()['n'],'orders':c.execute('SELECT COUNT(*) n FROM orders').fetchone()['n'],'new_orders':c.execute("SELECT COUNT(*) n FROM orders WHERE status='Nieuw'").fetchone()['n'],'revenue':c.execute("SELECT COALESCE(SUM(total),0) n FROM orders WHERE status NOT IN ('Geannuleerd')").fetchone()['n']}; c.close()
    return render_template('admin.html', products=products, orders=orders, stats=stats)

@app.route('/admin/product/new', methods=['POST'])
@admin_required
def product_new(): return save_product()

@app.route('/admin/product/<int:pid>/edit', methods=['POST'])
@admin_required
def product_edit(pid): return save_product(pid)

def save_product(pid=None):
    name=request.form.get('name','').strip(); description=request.form.get('description','').strip(); price=float(request.form.get('price') or 0); stock=int(request.form.get('stock') or 0); visible=1 if request.form.get('visible') else 0
    c=db(); old=c.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone() if pid else None
    image=old['image'] if old else ''
    f=request.files.get('image')
    if f and f.filename and allowed_file(f.filename):
        ext=f.filename.rsplit('.',1)[1].lower(); image=f'{uuid.uuid4().hex}.{ext}'; f.save(os.path.join(UPLOADS,image))
    if not name: flash('Productnaam is verplicht.','error'); return redirect(url_for('admin'))
    if pid: c.execute('UPDATE products SET name=?,description=?,price=?,stock=?,image=?,visible=? WHERE id=?',(name,description,price,stock,image,visible,pid))
    else: c.execute('INSERT INTO products(name,description,price,stock,image,visible,created_at) VALUES(?,?,?,?,?,?,?)',(name,description,price,stock,image,visible,datetime.utcnow().isoformat()))
    c.commit(); c.close(); return redirect(url_for('admin'))

@app.route('/admin/product/<int:pid>/delete', methods=['POST'])
@admin_required
def product_delete(pid):
    c=db(); p=c.execute('SELECT image FROM products WHERE id=?',(pid,)).fetchone(); c.execute('DELETE FROM products WHERE id=?',(pid,)); c.commit(); c.close()
    if p and p['image']:
        try: os.remove(os.path.join(UPLOADS,p['image']))
        except OSError: pass
    return redirect(url_for('admin'))

@app.route('/uploads/<path:name>')
def uploads(name): return send_from_directory(UPLOADS,name)

@app.route('/cart')
def cart():
    ids=session.get('cart',{}); c=db(); items=[]; total=0
    for sid,q in ids.items():
        p=c.execute('SELECT * FROM products WHERE id=? AND visible=1',(int(sid),)).fetchone()
        if p:
            subtotal=p['price']*q; total+=subtotal; items.append((p,q,subtotal))
    c.close(); return render_template('cart.html',items=items,total=total)

@app.post('/cart/add')
def cart_add():
    pid=str(request.form.get('product_id')); qty=max(1,int(request.form.get('quantity') or 1)); cart=session.get('cart',{}); cart[pid]=cart.get(pid,0)+qty; session['cart']=cart; return redirect(url_for('cart'))

@app.post('/cart/update')
def cart_update():
    cart={}
    for k,v in request.form.items():
        if k.startswith('qty_'):
            try:
                q=int(v); pid=k[4:]
                if q>0: cart[pid]=q
            except ValueError: pass
    session['cart']=cart; return redirect(url_for('cart'))

@app.route('/checkout', methods=['GET','POST'])
def checkout():
    cart=session.get('cart',{}); c=db(); rows=[]; total=0
    for sid,q in cart.items():
        p=c.execute('SELECT * FROM products WHERE id=? AND visible=1',(int(sid),)).fetchone()
        if p and q<=p['stock']:
            rows.append((p,q)); total += p['price']*q
    if request.method=='POST':
        if not rows: c.close(); flash('Je winkelmandje is leeg of een product is niet meer op voorraad.','error'); return redirect(url_for('cart'))
        name=request.form.get('name','').strip(); email=request.form.get('email','').strip(); address=request.form.get('address','').strip()
        if not name or not email: c.close(); flash('Naam en e-mail zijn verplicht.','error'); return redirect(url_for('checkout'))
        now=datetime.utcnow().isoformat(); cur=c.execute('INSERT INTO orders(customer_name,email,address,total,created_at) VALUES(?,?,?,?,?)',(name,email,address,total,now)); oid=cur.lastrowid
        for p,q in rows:
            c.execute('INSERT INTO order_items(order_id,product_id,product_name,price,quantity) VALUES(?,?,?,?,?)',(oid,p['id'],p['name'],p['price'],q)); c.execute('UPDATE products SET stock=stock-? WHERE id=?',(q,p['id']))
        c.commit(); c.close(); session['cart']={}; return render_template('success.html',order_id=oid)
    c.close(); return render_template('checkout.html',items=rows,total=total)

@app.post('/admin/order/<int:oid>/status')
@admin_required
def order_status(oid):
    status=request.form.get('status','Nieuw');
    if status not in {'Nieuw','In behandeling','Verzonden','Afgerond','Geannuleerd'}: status='Nieuw'
    c=db(); c.execute('UPDATE orders SET status=? WHERE id=?',(status,oid)); c.commit(); c.close(); return redirect(url_for('admin'))

@app.route('/api/products')
def api_products():
    c=db(); data=[dict(x) for x in c.execute('SELECT * FROM products WHERE visible=1 ORDER BY id DESC').fetchall()]; c.close(); return jsonify(data)

with app.app_context(): init_db()

if __name__=='__main__': app.run(host='0.0.0.0', port=int(os.environ.get('PORT',5000)), debug=True)
