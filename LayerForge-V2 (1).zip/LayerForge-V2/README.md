# LayerForge V2

Flask webshop for 3D prints with admin dashboard, product management, image upload, stock and orders.

## Local

```bash
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
py app.py
```

Open http://127.0.0.1:5000

Default admin for local development:
- username: `admin`
- password: `change-me`

## Render

Build command:
`pip install -r requirements.txt`

Start command:
`gunicorn app:app`

Recommended environment variables:
- `SECRET_KEY` = a long random secret
- `ADMIN_USERNAME` = your admin username
- `ADMIN_PASSWORD` = a strong password

## Important storage note

This V2 uses SQLite and local uploads for the first deployment. Render Free has ephemeral filesystem storage, so for production persistence we should move the database to PostgreSQL and images to object/image storage before relying on the shop for real orders.
